
char *host_name = "";
