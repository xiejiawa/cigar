#include <zebra.h>
#include "command.h"
#include "vtysh.h"

void
vtysh_init_cmd ()
{
}
